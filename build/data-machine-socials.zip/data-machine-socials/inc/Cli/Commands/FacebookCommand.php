<?php
/**
 * WP-CLI Facebook Command
 *
 * @package    DataMachineSocials
 * @subpackage Cli\Commands
 * @since      0.3.0
 */

namespace DataMachineSocials\Cli\Commands;

use WP_CLI;
use DataMachine\Abilities\AuthAbilities;

defined( 'ABSPATH' ) || exit;

/**
 * Manage Facebook integration for Data Machine Socials.
 *
 * ## EXAMPLES
 *
 *     wp datamachine-socials facebook posts
 *     wp datamachine-socials facebook post 123456789
 *     wp datamachine-socials facebook comments 123456789
 *     wp datamachine-socials facebook status
 */
class FacebookCommand {

	/**
	 * List recent Facebook Page posts.
	 *
	 * ## OPTIONS
	 *
	 * [--limit=<limit>]
	 * : Number of posts to return.
	 * ---
	 * default: 25
	 * ---
	 *
	 * [--after=<cursor>]
	 * : Pagination cursor for next page.
	 *
	 * [--format=<format>]
	 * : Output format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 * ---
	 */
	public function posts( $args, $assoc_args ) {
		$ability = $this->get_ability();

		$result = $ability->execute( array(
			'action' => 'list',
			'limit'  => absint( $assoc_args['limit'] ?? 25 ),
			'after'  => $assoc_args['after'] ?? '',
		) );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		$data   = $result['data'];
		$posts  = $data['posts'] ?? array();
		$format = $assoc_args['format'] ?? 'table';

		if ( empty( $posts ) ) {
			WP_CLI::warning( 'No posts found.' );
			return;
		}

		if ( 'json' === $format ) {
			WP_CLI::log( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			return;
		}

		WP_CLI::success( "Found {$data['count']} posts" );
		WP_CLI::log( '' );

		foreach ( $posts as $item ) {
			$message = mb_substr( $item['message'] ?? '(no message)', 0, 60 );
			if ( mb_strlen( $item['message'] ?? '' ) > 60 ) {
				$message .= '...';
			}
			$likes    = $item['likes']['summary']['total_count'] ?? 0;
			$comments = $item['comments']['summary']['total_count'] ?? 0;
			$shares   = $item['shares']['count'] ?? 0;
			$date     = isset( $item['created_time'] ) ? wp_date( 'Y-m-d', strtotime( $item['created_time'] ) ) : '';

			WP_CLI::log( sprintf(
				'  %s  %s  %d likes  %d comments  %d shares  %s',
				$item['id'],
				$date,
				$likes,
				$comments,
				$shares,
				$message
			) );
		}

		if ( $data['has_next'] && ! empty( $data['cursors']['after'] ) ) {
			WP_CLI::log( '' );
			WP_CLI::log( "Next page: --after={$data['cursors']['after']}" );
		}
	}

	/**
	 * Get details for a specific Facebook post.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The Facebook post ID.
	 *
	 * [--format=<format>]
	 * : Output format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 * ---
	 */
	public function post( $args, $assoc_args ) {
		$post_id = $args[0];
		$ability = $this->get_ability();

		$result = $ability->execute( array(
			'action'  => 'get',
			'post_id' => $post_id,
		) );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		$data   = $result['data'];
		$format = $assoc_args['format'] ?? 'table';

		if ( 'json' === $format ) {
			WP_CLI::log( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			return;
		}

		WP_CLI::success( "Post {$post_id}" );
		WP_CLI::log( '' );
		WP_CLI::log( 'ID:        ' . ( $data['id'] ?? '' ) );
		WP_CLI::log( 'Date:      ' . ( $data['created_time'] ?? '' ) );
		WP_CLI::log( 'Likes:     ' . ( $data['likes']['summary']['total_count'] ?? 0 ) );
		WP_CLI::log( 'Comments:  ' . ( $data['comments']['summary']['total_count'] ?? 0 ) );
		WP_CLI::log( 'Shares:    ' . ( $data['shares']['count'] ?? 0 ) );
		WP_CLI::log( 'Permalink: ' . ( $data['permalink_url'] ?? '' ) );
		WP_CLI::log( '' );
		WP_CLI::log( 'Message:' );
		WP_CLI::log( $data['message'] ?? '(no message)' );
	}

	/**
	 * Get comments on a Facebook post.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The Facebook post ID.
	 *
	 * [--limit=<limit>]
	 * : Number of comments to return.
	 * ---
	 * default: 25
	 * ---
	 *
	 * [--format=<format>]
	 * : Output format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 * ---
	 */
	public function comments( $args, $assoc_args ) {
		$post_id = $args[0];
		$ability = $this->get_ability();

		$result = $ability->execute( array(
			'action'  => 'comments',
			'post_id' => $post_id,
			'limit'   => absint( $assoc_args['limit'] ?? 25 ),
		) );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		$data     = $result['data'];
		$comments = $data['comments'] ?? array();
		$format   = $assoc_args['format'] ?? 'table';

		if ( empty( $comments ) ) {
			WP_CLI::warning( 'No comments found.' );
			return;
		}

		if ( 'json' === $format ) {
			WP_CLI::log( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			return;
		}

		WP_CLI::success( "Found {$data['count']} comments" );
		WP_CLI::log( '' );

		foreach ( $comments as $comment ) {
			$from = $comment['from']['name'] ?? 'unknown';
			$text = $comment['message'] ?? '';
			$date = isset( $comment['created_time'] ) ? wp_date( 'Y-m-d H:i', strtotime( $comment['created_time'] ) ) : '';

			WP_CLI::log( sprintf( '  %-20s %s  %s', $from, $date, $text ) );
		}
	}

	/**
	 * Show Facebook authentication status.
	 *
	 * ## EXAMPLES
	 *
	 *     wp datamachine-socials facebook status
	 */
	public function status( $args, $assoc_args ) {
		$args;
		$assoc_args;
		$auth_abilities = new AuthAbilities();
		$provider       = $auth_abilities->getProvider( 'facebook' );

		WP_CLI::log( 'Facebook Integration Status' );
		WP_CLI::log( '---' );

		if ( ! $provider ) {
			WP_CLI::log( 'Provider:      Not found' );
			return;
		}

		$authenticated = $provider->is_authenticated();
		WP_CLI::log( 'Authenticated: ' . ( $authenticated ? 'Yes' : 'No' ) );

		if ( method_exists( $provider, 'get_page_id' ) ) {
			$page_id = $provider->get_page_id();
			if ( $page_id ) {
				WP_CLI::log( 'Page ID:       ' . $page_id );
			}
		}

		$details = $provider->get_account_details();
		if ( $details ) {
			if ( ! empty( $details['page_name'] ) ) {
				WP_CLI::log( 'Page:          ' . $details['page_name'] );
			}
			if ( ! empty( $details['user_name'] ) ) {
				WP_CLI::log( 'User:          ' . $details['user_name'] );
			}
		}

		$next_cron = wp_next_scheduled( 'datamachine_refresh_token_facebook' );
		if ( $next_cron ) {
			WP_CLI::log( 'Next cron:     ' . wp_date( 'Y-m-d H:i:s', $next_cron ) );
		}
	}

	/**
	 * Publish a post to Facebook.
	 *
	 * Posts content to a Facebook Page with optional image and source URL.
	 *
	 * ## OPTIONS
	 *
	 * <content>
	 * : The post content text.
	 *
	 * [--title=<title>]
	 * : Optional title to prepend to the post.
	 *
	 * [--image=<url>]
	 * : Image URL to attach to the post.
	 *
	 * [--source-url=<url>]
	 * : Source URL to include in the post.
	 *
	 * [--link-handling=<handling>]
	 * : How to handle the source URL: none, append (default), or comment.
	 * ---
	 * default: append
	 * options:
	 *   - none
	 *   - append
	 *   - comment
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     # Simple text post
	 *     wp datamachine-socials facebook publish "Check out our latest article!"
	 *
	 *     # Post with image
	 *     wp datamachine-socials facebook publish "New photo from the show" --image=https://example.com/photo.jpg
	 *
	 *     # Post with source URL as comment
	 *     wp datamachine-socials facebook publish "Great read" --source-url=https://extrachill.com/article --link-handling=comment
	 */
	public function publish( $args, $assoc_args ) {
		$content = $args[0] ?? '';

		if ( empty( $content ) ) {
			WP_CLI::error( 'Post content is required.' );
		}

		$this->get_publish_ability();

		$input = array( 'content' => $content );

		if ( ! empty( $assoc_args['title'] ) ) {
			$input['title'] = $assoc_args['title'];
		}

		if ( ! empty( $assoc_args['image'] ) ) {
			$input['image_url'] = $assoc_args['image'];
			WP_CLI::log( 'Publishing to Facebook with image...' );
		} else {
			WP_CLI::log( 'Publishing to Facebook...' );
		}

		if ( ! empty( $assoc_args['source-url'] ) ) {
			$input['source_url'] = $assoc_args['source-url'];
		}

		if ( ! empty( $assoc_args['link-handling'] ) ) {
			$input['link_handling'] = $assoc_args['link-handling'];
		}

		$result = \DataMachineSocials\Abilities\Facebook\FacebookPublishAbility::execute_publish( $input );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		WP_CLI::success( 'Published to Facebook!' );
		WP_CLI::log( 'Post ID:  ' . ( $result['post_id'] ?? '' ) );
		WP_CLI::log( 'Post URL: ' . ( $result['post_url'] ?? '' ) );

		if ( ! empty( $result['comment_id'] ) ) {
			WP_CLI::log( 'Comment ID:  ' . $result['comment_id'] );
			WP_CLI::log( 'Comment URL: ' . ( $result['comment_url'] ?? '' ) );
		}
	}

	private function get_ability() {
		if ( ! function_exists( 'wp_get_ability' ) ) {
			WP_CLI::error( 'WordPress Abilities API not available (requires WP 6.9+).' );
		}

		$ability = wp_get_ability( 'datamachine/facebook-read' );
		if ( ! $ability ) {
			WP_CLI::error( 'datamachine/facebook-read ability not registered.' );
		}

		return $ability;
	}

	private function get_update_ability() {
		if ( ! function_exists( 'wp_get_ability' ) ) {
			WP_CLI::error( 'WordPress Abilities API not available (requires WP 6.9+).' );
		}

		$ability = wp_get_ability( 'datamachine/facebook-update' );
		if ( ! $ability ) {
			WP_CLI::error( 'datamachine/facebook-update ability not registered.' );
		}

		return $ability;
	}

	private function get_delete_ability() {
		if ( ! function_exists( 'wp_get_ability' ) ) {
			WP_CLI::error( 'WordPress Abilities API not available (requires WP 6.9+).' );
		}

		$ability = wp_get_ability( 'datamachine/facebook-delete' );
		if ( ! $ability ) {
			WP_CLI::error( 'datamachine/facebook-delete ability not registered.' );
		}

		return $ability;
	}

	private function get_publish_ability() {
		if ( ! function_exists( 'wp_get_ability' ) ) {
			WP_CLI::error( 'WordPress Abilities API not available (requires WP 6.9+).' );
		}

		$ability = wp_get_ability( 'datamachine/facebook-publish' );
		if ( ! $ability ) {
			WP_CLI::error( 'datamachine/facebook-publish ability not registered.' );
		}

		return $ability;
	}

	/**
	 * Edit a Facebook post message.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The Facebook post ID.
	 *
	 * <message>
	 * : New message text.
	 *
	 * ## EXAMPLES
	 *
	 *     wp datamachine-socials facebook edit 123456789 "New message"
	 */
	public function edit( $args, $assoc_args ) {
		$assoc_args;
		$post_id = $args[0];
		$message = $args[1] ?? '';
		$ability = $this->get_update_ability();

		if ( empty( $message ) ) {
			WP_CLI::error( 'Message is required.' );
		}

		$result = $ability->execute( array(
			'action'  => 'edit',
			'post_id' => $post_id,
			'message' => $message,
		) );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		WP_CLI::success( 'Post updated successfully!' );
		WP_CLI::log( 'Post ID: ' . $result['data']['post_id'] );
	}

	/**
	 * Hide a Facebook post.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The Facebook post ID to hide.
	 *
	 * ## EXAMPLES
	 *
	 *     wp datamachine-socials facebook hide 123456789
	 */
	public function hide( $args, $assoc_args ) {
		$assoc_args;
		$post_id = $args[0];
		$ability = $this->get_update_ability();

		$result = $ability->execute( array(
			'action'  => 'hide',
			'post_id' => $post_id,
		) );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		WP_CLI::success( 'Post hidden successfully!' );
	}

	/**
	 * Delete a Facebook post.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The Facebook post ID to delete.
	 *
	 * ## EXAMPLES
	 *
	 *     wp datamachine-socials facebook delete 123456789
	 */
	public function delete( $args, $assoc_args ) {
		$assoc_args;
		$post_id = $args[0];
		$ability = $this->get_delete_ability();

		$result = $ability->execute( array(
			'post_id' => $post_id,
		) );

		if ( ! $result['success'] ) {
			WP_CLI::error( $result['error'] );
		}

		WP_CLI::success( 'Post deleted successfully!' );
		WP_CLI::log( 'Post ID: ' . $result['data']['post_id'] );
	}
}
